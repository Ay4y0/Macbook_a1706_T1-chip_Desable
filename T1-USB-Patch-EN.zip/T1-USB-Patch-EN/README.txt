T1 USB Patch 1.0.1 — English

Hides a stuck internal Apple T1 in DFU/Recovery from macOS through an
OpenCore USB map. This does not restore firmware or repair Touch ID/Touch Bar.

Requires a T1 MacBook Pro (A1706/A1707, 2016–2017), existing OpenCore/OCLP,
and a prepared FAT32 USB drive for the first test. Unknown maps/controllers
are rejected. Hardware-tested on one A1706; other models need their own test.

1. Open Start.command. No Homebrew, Python, or third-party libraries needed.
   To create an app and portable ZIP, open Make-App.command once on macOS.
2. Choose "Check and save report". If T1 is already hidden by an active map,
   reinstallation is unnecessary.
3. Choose "Prepare USB test" and your original EFI/OC. Only a Desktop copy
   is changed. Manually copy its EFI folder to the prepared USB drive.
4. Boot the USB via Option -> EFI Boot -> macOS. Test keyboard, trackpad,
   USB 2/USB 3 in every connector, and your device tools. Do not reset NVRAM.
5. Choose "Install after USB test" and the generated T1-USB-Test folder.
   Read the destination paths. A backup is created before installation.
   Reboot without the USB drive and check again.

Rollback: open Rollback.command inside T1-USB-Backup, or choose "Restore
from backup". If macOS cannot boot, use the working USB first.
Keep that USB, your backup, and the portable ZIP on another disk.
"Reapply tested patch" accepts a saved profile.json only for a matching Mac,
OS major version, controller, and port inventory. No personal profiles ship.

Changing the boot USB map can disable devices or affect macOS startup.
The program does not format/repartition disks, flash T1, change ACPI,
reset NVRAM, mount volumes, or replace OpenCore.efi/boot.efi. It changes
the map Info.plist and, when adding a new map, one Kernel/Add entry.
Windows is not supported. A hidden T1 is also unavailable to T1 firmware tools.

The new English interface has not yet been hardware-tested. Shared map
logic and the original Russian diagnostic interface were tested on the A1706.
Review any reports/profiles before posting them publicly: they may identify
your device. Do not publish backups or the generated test EFI folder.

MIT License; see LICENSE. OpenCore/OCLP are separate and not bundled.
