#!/bin/bash
set -eu
backup_dir="$(cd -- "$(dirname -- "$0")" && pwd -P)"
exec /usr/bin/osascript -l JavaScript "$backup_dir/patch.js" "$backup_dir" --restore "$backup_dir"
