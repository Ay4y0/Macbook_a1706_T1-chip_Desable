#!/bin/bash
set -eu
package_dir="$(cd -- "$(dirname -- "$0")" && pwd -P)"
exec /usr/bin/osascript -l JavaScript "$package_dir/patch.js" "$package_dir" "$@"
