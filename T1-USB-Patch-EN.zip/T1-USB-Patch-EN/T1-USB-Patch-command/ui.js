/* Native macOS adapter; all device and plist decisions are in engine.js. */
function run(argv) {
    'use strict';
    ObjC.import('Foundation');
    var E=T1Patch,app=Application.currentApplication();app.includeStandardAdditions=true;
    var fm=$.NSFileManager.defaultManager,home=ObjC.unwrap($.NSHomeDirectory()),desk=home+'/Desktop';
    var title='T1 USB Patch 1.0.1',log='',activeWrite=false;
    var resources=argv.length?String(argv[0]):ObjC.unwrap($.NSBundle.mainBundle.resourcePath);
    var storage=home+'/Library/Application Support/T1 USB Patch';
    function fail(s){throw new Error(s);}
    function exists(p){return !!fm.fileExistsAtPath($(p));}
    function data(p){var d=$.NSData.dataWithContentsOfFile($(p));if(!d)fail("Could not read "+p);return d;}
    function writeData(p,d){if(!d.writeToFileAtomically($(p),true))fail("Could not write "+p);}
    function text(p){var s=$.NSString.alloc.initWithDataEncoding(data(p),$.NSUTF8StringEncoding);if(!s)fail("Not UTF-8: "+p);return ObjC.unwrap(s);}
    function write(p,s){if(!$(String(s)).writeToFileAtomicallyEncodingError($(p),true,$.NSUTF8StringEncoding,null))fail("Could not write "+p);}
    function mkdir(p){if(!fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(p),true,$({NSFilePosixPermissions:448}),null))fail("Could not create "+p);}
    function copy(a,b){if(exists(b))fail("Destination already exists: "+b);if(!fm.copyItemAtPathToPathError($(a),$(b),null))fail("Could not copy "+a+' → '+b);}
    function remove(p){if(!fm.removeItemAtPathError($(p),null))fail("Could not remove "+p);}
    function cap(exe,args){
        var t=$.NSTask.alloc.init,p=$.NSPipe.pipe;
        t.launchPath=$(exe);t.arguments=$(args);t.standardOutput=p;t.standardError=p;
        var env=ObjC.deepUnwrap($.NSProcessInfo.processInfo.environment);
        Object.keys(env).forEach(function(k){if(/^(DYLD_|LD_)/.test(k))delete env[k];});
        t.environment=$(env);t.launch;
        var d=p.fileHandleForReading.readDataToEndOfFile;t.waitUntilExit;
        var s=ObjC.unwrap($.NSString.alloc.initWithDataEncoding(d,$.NSUTF8StringEncoding))||'';
        if(Number(t.terminationStatus)!==0)fail(exe+" failed: "+s.slice(-1500));return s;
    }
    function hash(p){var h=cap('/usr/bin/shasum',['-a','256',p]).split(/\s+/)[0];if(!/^[0-9a-f]{64}$/.test(h))fail("SHA-256 check failed");return h;}
    function plist(p){return E.parse(cap('/usr/bin/plutil',['-convert','xml1','-o','-',p]));}
    function json(p){return JSON.parse(text(p));}
    function saveJSON(p,o){write(p,JSON.stringify(o,null,2)+'\n');}
    function savePlist(p,o){write(p,E.xml(o));cap('/usr/bin/plutil',['-lint',p]);if(!E.eq(plist(p),o))fail("Written plist verification failed: "+p);}
    function stamp(){return new Date().toISOString().replace(/[:.]/g,'-');}
    function message(s){app.displayDialog(s,{withTitle:title,buttons:["Close"],defaultButton:"Close"});}
    function confirm(s,label){return app.displayDialog(s,{withTitle:title,buttons:["Cancel",label],defaultButton:"Cancel",cancelButton:"Cancel"}).buttonReturned===label;}
    function folder(prompt,initial){
        var opts={withPrompt:prompt};if(initial&&exists(initial))opts.defaultLocation=Path(initial);
        return String(app.chooseFolder(opts)).replace(/\/$/,'');
    }
    function real(p){return ObjC.unwrap($(p).stringByStandardizingPath.stringByResolvingSymlinksInPath);}
    function noLinks(p){var q=p;while(!exists(q)&&q!=='/')q=q.split('/').slice(0,-1).join('/')||'/';if(real(q)!==q)fail("Symbolic link in path: "+p);}
    function safeOC(p){
        if(real(p)!==p||!/(?:^|\/)EFI\/OC$/.test(p)||p.indexOf('/dev/')===0||p.indexOf('/System/')===0)fail("Select the actual EFI/OC folder without symbolic links");
        if(!exists(p+'/config.plist')||!exists(p+'/OpenCore.efi'))fail("The selected folder does not contain config.plist and OpenCore.efi");
        noLinks(p+'/config.plist');noLinks(p+'/OpenCore.efi');
        return p;
    }
    function ocFolder(){return safeOC(folder("Select the EFI/OC folder of your OpenCore installation. Check that you selected the correct boot volume.",'/Volumes'));}
    function tree(){return E.parse(cap('/usr/sbin/ioreg',['-a','-l','-r','-c','AppleUSBHostController']));}
    function model(){return cap('/usr/sbin/sysctl',['-n','hw.model']).trim();}
    function darwin(){return cap('/usr/sbin/sysctl',['-n','kern.osrelease']).trim().split('.')[0];}
    function locate(){return E.locate(tree(),model(),darwin());}
    function canWrite(p){if(!fm.isWritableFileAtPath($(p)))fail("No write access: "+p+"\nThis tool does not mount volumes or request administrator privileges.");}
    function linksAndFiles(oc){
        var out={},it=fm.enumeratorAtPath($(oc)),x;
        while((x=it.nextObject)){var rel=ObjC.unwrap(x),p=oc+'/'+rel;
            E.path(rel);var a=fm.attributesOfItemAtPathError($(p),null),type=ObjC.unwrap(a.objectForKey($.NSFileType));
            if(type==='NSFileTypeSymbolicLink')fail("Symbolic link in OC: "+rel);
            if(type==='NSFileTypeRegular')out[rel]=hash(p);
            else if(type!=='NSFileTypeDirectory')fail("Unsupported file type in OC: "+rel);
        }return out;
    }
    function assertSnapshot(root,snap){Object.keys(snap).forEach(function(r){if(!exists(root+'/'+r)||hash(root+'/'+r)!==snap[r])fail("The source OpenCore installation has changed: "+r);});}
    function context(oc,plan,id){
        var cfg=plist(oc+'/config.plist'),entries=cfg.Kernel&&cfg.Kernel.Add;
        if(!Array.isArray(entries))fail("Kernel/Add is missing from config.plist");
        var maps=[];
        entries.forEach(function(e){
            if(e.Enabled!==true)return;E.path(e.BundlePath);
            if(/USBToolBox|UTBMap|USBInjectAll|GenericUSBXHCI/i.test(e.BundlePath))fail("Another USB mapping or injection mechanism is enabled: "+e.BundlePath+"; a separate review is required");
            var pp=e.PlistPath||'Contents/Info.plist';E.path(pp);
            var f=oc+'/Kexts/'+e.BundlePath+'/'+pp;if(!exists(f))fail("An enabled kext is missing: "+f);noLinks(f);
            var m=plist(f),isMap=/USB.?Map|USBPorts|T1-USB-Map/i.test(e.BundlePath),hasPorts=false;
            ['IOKitPersonalities','IOKitPersonalities_x86_64'].forEach(function(k){Object.keys(m[k]||{}).forEach(function(n){
                var p=m[k][n],v=p.IOProviderMergeProperties||{};if(v.ports||v.portCount||v['port-count'])hasPorts=true;
            });});
            if(isMap||hasPorts){if(e.ExecutablePath||pp!=='Contents/Info.plist'||e.BundlePath.indexOf('/')>=0)fail("This nonstandard USB map requires a separate review");maps.push({entry:e,relative:'Kexts/'+e.BundlePath+'/'+pp,map:m});}
        });
        if(maps.length>1)fail("Multiple USB maps are enabled; automatic replacement is disabled");
        var p=E.personality(plan,id),result={config:cfg,changeConfig:false,files:[]},map;
        if(maps.length){map=maps[0];map.map=E.patchMap(map.map,p);}
        else {
            var rel='Kexts/T1-USB-Map.kext/Contents/Info.plist';if(exists(oc+'/Kexts/T1-USB-Map.kext'))fail("A disabled T1-USB-Map.kext already exists. Manual review is required");
            map={relative:rel,map:E.patchMap(E.newMap(),p)};
            cfg.Kernel.Add.push({Arch:'x86_64',BundlePath:'T1-USB-Map.kext',Comment:'T1 internal USB port exclusion',Enabled:true,ExecutablePath:'',MaxKernel:'',MinKernel:'',PlistPath:'Contents/Info.plist'});
            result.changeConfig=true;
        }
        result.map=map;return result;
    }
    function selfCheck(){
        var f=storage+'/self-check.plist',sample={text:"Test & < > \"",bytes:{$data:'AwAAAA=='},large:{$integer:'18446744073709551615'},real:{$real:'1.25'},yes:true,no:false,array:[1,-1,'x'],empty:{}};
        savePlist(f,sample);remove(f);
        if(cap('/usr/bin/uname',['-m']).trim()!=='x86_64')fail("This tool is intended for Intel MacBook Pro models with T1");
    }
    function diagnose(){
        var t=tree(),hits=[],markers=[];
        E.walk(t,function(n){var id=E.t1(n);if(id)hits.push(id);if(n.T1USBPatchProfile||n.T1HideTestMap)markers.push({controller:E.signature(n),profile:n.T1USBPatchProfile||n.T1HideTestMap,ports:E.inventory(n)});});
        var report={version:'1.0.1',model:model(),darwin:darwin(),T1:hits,markers:markers};
        try{report.plan=E.locate(t,report.model,report.darwin);}catch(e){report.note=String(e);}
        var out=desk+'/T1-USB-Report-'+stamp()+'.json';saveJSON(out,report);
        message((hits.length?'T1: '+hits.map(function(h){return h.mode+' / ECID '+h.ecid;}).join(', '):"No T1 device is visible in DFU/Recovery.")+'\n'+(markers.length?"A USB map marker is active.":"No active marker from this tool was found.")+"\n\nReport: "+out);
    }
    function prepare(){
        var plan=locate(),oc=ocFolder(),id='T1USB-'+stamp(),c=context(oc,plan,id),snap=linksAndFiles(oc);
        var volume=oc.slice(0,-'/EFI/OC'.length),boots=[volume+'/EFI/BOOT/BOOTx64.efi',volume+'/System/Library/CoreServices/boot.efi'];
        var boot=boots.filter(exists)[0];if(!boot)fail("The original BOOTx64.efi/boot.efi was not found on the OpenCore volume. The boot configuration needs a separate review");
        if(real(boot)!==boot)fail("The bootstrap file is a symbolic link");
        var bootHash=hash(boot),out=desk+'/T1-USB-Test-'+stamp();mkdir(out);
        write(out+'/INCOMPLETE.txt',"Do not use this folder until READY.txt appears.");
        mkdir(out+'/EFI');copy(oc,out+'/EFI/OC');mkdir(out+'/EFI/BOOT');copy(boot,out+'/EFI/BOOT/BOOTx64.efi');
        var test=E.copy(c.config);if(!test.Misc||!test.Misc.Boot)fail("Misc/Boot is missing from config.plist");test.Misc.Boot.LauncherOption='Disabled';
        savePlist(out+'/EFI/OC/config.plist',test);mkdir(out+'/EFI/OC/'+c.map.relative.split('/').slice(0,-1).join('/'));savePlist(out+'/EFI/OC/'+c.map.relative,c.map.map);
        var copied=linksAndFiles(out+'/EFI/OC'),allowed=['config.plist',c.map.relative];
        Object.keys(snap).forEach(function(r){if(allowed.indexOf(r)<0&&copied[r]!==snap[r])fail("Another file was changed in the copy: "+r);});
        Object.keys(copied).forEach(function(r){if(!snap[r]&&allowed.indexOf(r)<0)fail("Unexpected file in the copy: "+r);});
        assertSnapshot(oc,snap);if(hash(boot)!==bootHash)fail("The original bootstrap file has changed");
        var ticket={schema:1,id:id,plan:plan,source:oc,snapshot:snap,mapRelative:c.map.relative,created:new Date().toISOString()};
        saveJSON(out+'/profile.json',ticket);mkdir(out+'/Original-files');copy(oc+'/config.plist',out+'/Original-files/config.plist');
        if(exists(oc+'/'+c.map.relative))copy(oc+'/'+c.map.relative,out+'/Original-files/USB-Map-Info.plist');
        write(out+'/README-EN.txt',"PREPARED ON THE DESKTOP ONLY.\n\n1. Manually copy the EFI folder from here to an already prepared FAT32 USB drive. Do not copy it to the internal disk. Back up any existing EFI folder on the USB drive first.\n2. Restart while holding Option, select the USB drive EFI Boot, then macOS. Do not reset NVRAM.\n3. Test the built-in keyboard and trackpad, USB 2 and USB 3 devices in every USB connector, and your device tools. T1 should disappear.\n4. Open T1 USB Patch, choose \"Install after USB test\", and select THIS folder (containing profile.json).\n5. If anything fails, shut down, remove the USB drive, and boot your original OpenCore installation. Preparation did not change the internal bootloader.\n\nPort "+plan.target.name+" / physical number "+plan.target.number+'; ECID '+plan.ecid+'.\n');
        remove(out+'/INCOMPLETE.txt');write(out+'/READY.txt',"Ready to manually copy EFI to your test USB drive.\n");
        cap('/usr/bin/open',[out]);message("Test files are ready on the Desktop:\n"+out+'\n\nT1: '+plan.target.name+' / ECID '+plan.ecid+"\nThe source OpenCore installation is unchanged. Nothing was written to the USB drive. Read README-EN.txt.");
    }
    function transaction(oc,c,profile){
        safeOC(oc);canWrite(oc);canWrite(oc+'/config.plist');
        var changes=[{relative:c.map.relative,content:E.xml(c.map.map)}];
        if(c.changeConfig)changes.push({relative:'config.plist',content:E.xml(c.config)});
        var seen={},backup=desk+'/T1-USB-Backup-'+stamp();mkdir(backup);
        var manifest={schema:1,target:oc,created:new Date().toISOString(),changes:[],profile:profile};
        changes.forEach(function(ch,i){
            E.path(ch.relative);if(seen[ch.relative])fail('Duplicate target');seen[ch.relative]=true;
            var p=oc+'/'+ch.relative;noLinks(p);var before=exists(p)?hash(p):null;
            if(before)copy(p,backup+'/original-'+i+'.plist');
            savePlist(backup+'/installed-'+i+'.plist',E.parse(ch.content));
            manifest.changes.push({relative:ch.relative,before:before,after:hash(backup+'/installed-'+i+'.plist'),index:i});
        });
        saveJSON(backup+'/manifest.json',manifest);saveJSON(backup+'/profile.json',profile);
        // Portable rollback can be run even from another macOS installation.
        copy(resources+'/patch.js',backup+'/patch.js');copy(resources+'/Rollback.command',backup+'/Rollback.command');
        write(backup+'/README-EN.txt',"To roll back, open Rollback.command. If macOS does not boot, start from your working test USB drive and open this file.\nRollback does not require an NVRAM reset or removing partitions.\n");
        if(!confirm("Files to change:\n"+manifest.changes.map(function(ch){return oc+'/'+ch.relative;}).join('\n')+"\n\nT1 port: "+profile.plan.target.name+"\nBackup: "+backup+"\n\nThis changes the bootloader USB map. An incorrect map can disable devices in macOS; keep a working USB boot drive for recovery.\nPartitions and the OpenCore.efi/boot.efi files are not changed.","Install"))return;
        // Check every target before starting, never mount or request admin privileges.
        manifest.changes.forEach(function(ch){var p=oc+'/'+ch.relative;noLinks(p);if((exists(p)?hash(p):null)!==ch.before)fail("A file changed before writing: "+p);if(exists(p))canWrite(p);});
        activeWrite=true;
        try {
            manifest.changes.forEach(function(ch){var p=oc+'/'+ch.relative;mkdir(p.split('/').slice(0,-1).join('/'));write(p,text(backup+'/installed-'+ch.index+'.plist'));if(hash(p)!==ch.after)fail("Written file verification failed: "+p);});
        } catch(e) {
            var errors=[];manifest.changes.slice().reverse().forEach(function(ch){try{var p=oc+'/'+ch.relative;if(ch.before){writeData(p,data(backup+'/original-'+ch.index+'.plist'));if(hash(p)!==ch.before)fail("Restored file verification failed: "+p);}else if(exists(p))remove(p);}catch(r){errors.push(String(r));}});
            activeWrite=false;throw new Error(String(e)+"\nRollback attempt: "+(errors.length?errors.join('\n'):"original files restored")+'\nBackup: '+backup);
        }
        activeWrite=false;
        // Backups must be byte-exact even for binary plist files. Originals were copied, not reserialized.
        saveJSON(backup+'/installed.json',{completed:true,at:new Date().toISOString()});
        mkdir(storage+'/Profiles');profile.tested=true;saveJSON(storage+'/Profiles/'+profile.plan.ecid+'.json',profile);
        message("Patch installed.\nBackup: "+backup+"\n\nRestart without the test USB drive, then choose \"Check and save report\". An OCLP update or rebuild may require applying the map again.");
    }
    function installTest(){
        var dir=folder("Select the T1-USB-Test folder containing profile.json",desk),ticket=json(dir+'/profile.json');
        if(ticket.schema!==1||!ticket.id||!ticket.plan||!ticket.snapshot)fail("Invalid test profile");
        if(model()!==ticket.plan.model||darwin()!==ticket.plan.darwin)fail("The Mac model or macOS version has changed since the test was prepared");
        E.verifyHidden(tree(),ticket.plan,ticket.id);
        if(!confirm("The active test map excludes "+ticket.plan.target.name+".\nHave you tested the built-in keyboard and trackpad, every USB connector, and the applications you need?\n\nIf anything fails, cancel and boot the original OpenCore installation without the USB drive.","All tested"))return;
        var oc=safeOC(ticket.source);assertSnapshot(oc,ticket.snapshot);
        var c=context(oc,ticket.plan,ticket.id);if(c.map.relative!==ticket.mapRelative)fail("The USB map location has changed");
        transaction(oc,c,{schema:1,id:ticket.id,plan:ticket.plan,tested:true});
    }
    function repeat(){
        var plan;
        try{plan=locate();}catch(e){
            var marked=[];E.walk(tree(),function(n){if(n.T1USBPatchProfile||n.T1HideTestMap)marked.push(n);});
            if(marked.length){message("A T1 hiding map is already active. Reinstallation is not currently required.\nUse \"Check and save report\".");return;}throw e;
        }
        var profile=null,saved=storage+'/Profiles/'+plan.ecid+'.json';
        if(exists(saved)){var s=json(saved);if(s.tested&&E.samePlan(s.plan,plan))profile=s;}
        if(!profile){
            message("No matching saved profile was found. If this Mac has already passed a USB test, select profile.json from its T1-USB-Backup folder. Otherwise cancel and choose \"Prepare USB test\".");
            var file=String(app.chooseFile({withPrompt:"Select a saved profile.json from a tested Mac, or cancel to prepare a USB test"})),imported=json(file);
            if(imported.schema!==1||imported.tested!==true||!E.samePlan(imported.plan,plan))fail("The profile does not match this Mac, USB port, or macOS version");profile=imported;
        }
        var oc=ocFolder(),id='T1USB-'+stamp(),c=context(oc,plan,id);
        if(c.changeConfig)fail("The USB map injection setup has changed. A new USB test is required first.");
        transaction(oc,c,{schema:1,id:id,plan:plan,tested:true});
    }
    function restore(dir){
        dir=dir||folder("Select the T1-USB-Backup folder containing manifest.json",desk);
        var m=json(dir+'/manifest.json');if(m.schema!==1||!Array.isArray(m.changes)||!m.changes.length||m.changes.length>2)fail("Invalid backup manifest");
        var oc=safeOC(m.target),changes=m.changes;
        changes.forEach(function(ch){E.path(ch.relative);if(ch.relative!=='config.plist'&&!/^Kexts\/[^/]+\.kext\/Contents\/Info\.plist$/.test(ch.relative))fail("Unexpected path in backup manifest");
            if(!/^[0-9a-f]{64}$/.test(ch.after)||[0,1].indexOf(ch.index)<0)fail("Invalid backup entry");
            if(ch.before&&hash(dir+'/original-'+ch.index+'.plist')!==ch.before)fail("The backup is damaged");
            var p=oc+'/'+ch.relative;noLinks(p);var current=exists(p)?hash(p):null;
            if(current!==ch.after&&current!==ch.before)fail("A file was changed by another application after installation; rollback stopped: "+p);
            if(exists(p))canWrite(p);canWrite(p.split('/').slice(0,-1).join('/'));
        });
        if(!confirm("Restore the original files from:\n"+dir+"\n\nDestination: "+oc+"\nThe T1 hiding patch will be removed.","Restore"))return;
        changes.slice().reverse().forEach(function(ch){var p=oc+'/'+ch.relative;if((exists(p)?hash(p):null)===ch.before)return;
            if(ch.before){var d=data(dir+'/original-'+ch.index+'.plist');if(!d.writeToFileAtomically($(p),true))fail("Could not restore "+p);if(hash(p)!==ch.before)fail("Rollback verification failed");}
            else remove(p);
        });
        message("Original files restored. Restart your Mac.\nAn empty, disabled folder for the new kext may remain if one was created.");
    }
    try {
        mkdir(storage);selfCheck();
        if(argv.length>1&&argv[1]==='--self-check')return 'T1 USB Patch: native plist and runtime self-check passed. No boot files changed.';
        if(argv.length>1&&argv[1]==='--restore'){restore(argv[2]);return;}
        var choices=["Check and save report","Reapply tested patch","Prepare USB test","Install after USB test","Restore from backup"];
        var selection=app.chooseFromList(choices,{withTitle:title,withPrompt:"Hide the internal T1 in DFU/Recovery from macOS.\nOn a different Mac, start with a USB test. This does not restore firmware.",defaultItems:[choices[0]],okButtonName:"Continue",cancelButtonName:"Close"});
        if(!selection)return;
        var action=String(selection[0]);
        if(action===choices[0])diagnose();if(action===choices[1])repeat();if(action===choices[2])prepare();if(action===choices[3])installTest();if(action===choices[4])restore();
    } catch(e) {
        if(e.errorNumber===-128||String(e).indexOf('User canceled')>=0)return;
        var error=String(e)+(activeWrite?"\nWarning: an error occurred during writing; use your backup.":'');
        try{log=storage+'/error-'+stamp()+'.txt';write(log,error+'\n');}catch(ignore){}
        message("Operation stopped.\n\n"+error+"\n\nLog: "+log);
        throw e;
    }
}
