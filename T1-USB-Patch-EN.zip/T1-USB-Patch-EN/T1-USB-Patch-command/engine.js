/* T1 USB Patch 1.0: portable, dependency-free planning and typed plist codec. */
var T1Patch = (function () {
    'use strict';
    function fail(s) { throw new Error(s); }
    function copy(x) { return JSON.parse(JSON.stringify(x)); }
    function stable(x) {
        if (Array.isArray(x)) return '[' + x.map(stable).join(',') + ']';
        if (x && typeof x === 'object') return '{' + Object.keys(x).sort().map(function (k) {
            return JSON.stringify(k) + ':' + stable(x[k]);
        }).join(',') + '}';
        return JSON.stringify(x);
    }
    function eq(a,b) { return stable(a) === stable(b); }
    function unesc(s) {
        return s.replace(/&(#x[0-9a-f]+|#[0-9]+|amp|lt|gt|quot|apos);/gi, function (_,e) {
            var names={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};
            if (e.charAt(0)!=='#') return names[e];
            var n=e.charAt(1).toLowerCase()==='x'?parseInt(e.slice(2),16):parseInt(e.slice(1),10);
            if (n>65535) {n-=65536;return String.fromCharCode(55296+(n>>10),56320+(n&1023));}
            return String.fromCharCode(n);
        });
    }
    function parse(xml) {
        var tokens=xml.replace(/<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<!--[\s\S]*?-->/g,'').match(/<[^>]*>|[^<]+/g)||[], i=0;
        function ws() {while(i<tokens.length && /^\s*$/.test(tokens[i])) i++;}
        function node() {
            ws(); var t=tokens[i++],m=/^<(dict|array|string|key|integer|real|data|date|true|false)(\s*\/?)>$/.exec(t||'');
            if(!m) fail('Unsupported plist element: '+t);
            var kind=m[1],empty=m[2].indexOf('/')>=0,out,txt='';
            if(kind==='dict'||kind==='array') {
                out=kind==='dict'?{}:[];
                if(empty) return out;
                while(true) {
                    ws();if(tokens[i]==='</'+kind+'>') {i++;return out;}
                    if(kind==='dict') {
                        if(!/^<key(?:\s*\/?)>/.test(tokens[i]||'')) fail('Expected plist key');
                        var k=node();if(Object.prototype.hasOwnProperty.call(out,k))fail('Duplicate plist key');
                        out[k]=node();
                    } else out.push(node());
                }
            }
            if(!empty) {
                if(tokens[i] && tokens[i].charAt(0)!=='<')txt=tokens[i++];
                if(tokens[i++]!=='</'+kind+'>')fail('Malformed plist '+kind);
            }
            if(kind==='true'||kind==='false')return kind==='true';
            if(kind==='data')return {$data:txt.replace(/\s/g,'')};
            if(kind==='date')return {$date:txt};
            if(kind==='integer') {
                txt=txt.trim();if(!/^-?(?:[0-9]+|0x[0-9a-f]+)$/i.test(txt))fail('Bad plist integer');
                var n=Number(txt);return Math.abs(n)>9007199254740991?{$integer:txt}:n;
            }
            if(kind==='real') {var r=Number(txt);if(!isFinite(r))fail('Unsupported non-finite real');return {$real:txt};}
            return unesc(txt);
        }
        ws();if(!/^<plist\s+version="1\.0"\s*>$/.test(tokens[i++]||''))fail('Not an XML plist');
        var result=node();ws();if(tokens[i++]!=='</plist>')fail('Incomplete plist');ws();
        if(i!==tokens.length)fail('Trailing plist data');return result;
    }
    function xml(x) {
        function esc(s) {return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
        function item(v) {
            if(v===true||v===false)return v?'<true/>':'<false/>';
            if(typeof v==='string')return '<string>'+esc(v)+'</string>';
            if(typeof v==='number') {
                if(!isFinite(v)||Math.floor(v)!==v||Math.abs(v)>9007199254740991)fail('Unsafe integer');
                return '<integer>'+v+'</integer>';
            }
            if(Array.isArray(v))return '<array>'+v.map(item).join('')+'</array>';
            if(!v||typeof v!=='object')fail('Unsupported plist value');
            if(Object.keys(v).length===1) {
                if(v.$data!==undefined)return '<data>'+esc(v.$data)+'</data>';
                if(v.$date!==undefined)return '<date>'+esc(v.$date)+'</date>';
                if(v.$integer!==undefined)return '<integer>'+esc(v.$integer)+'</integer>';
                if(v.$real!==undefined)return '<real>'+esc(v.$real)+'</real>';
            }
            return '<dict>'+Object.keys(v).map(function(k){return '<key>'+esc(k)+'</key>'+item(v[k]);}).join('')+'</dict>';
        }
        return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0">'+item(x)+'</plist>\n';
    }
    var b64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    function bytes(d) {
        if(!d||typeof d.$data!=='string'||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(d.$data))fail('Invalid plist data');
        var a=[],bits=0,v=0;
        d.$data.replace(/=/g,'').split('').forEach(function(c){v=(v<<6)|b64.indexOf(c);bits+=6;if(bits>=8){bits-=8;a.push((v>>bits)&255);}});return a;
    }
    function portNumber(p) {
        var a=bytes(p);if(a.length!==4)fail('Port is not four-byte data');
        var n=a[0]+a[1]*256+a[2]*65536+a[3]*16777216;if(n<1||n>255)fail('Unexpected physical port number');return n;
    }
    function portData(n) {
        var a=[n&255,(n>>8)&255,(n>>16)&255,(n>>24)&255],s='',v=0,b=0;
        a.forEach(function(x){v=(v<<8)|x;b+=8;while(b>=6){b-=6;s+=b64[(v>>b)&63];}});
        if(b)s+=b64[(v<<(6-b))&63];while(s.length%4)s+='=';return {$data:s};
    }
    function walk(n,f,anc) {
        anc=anc||[];if(Array.isArray(n)){n.forEach(function(x){walk(x,f,anc);});return;}
        if(!n||typeof n!=='object')return;f(n,anc);
        (n.IORegistryEntryChildren||[]).forEach(function(x){walk(x,f,anc.concat([n]));});
    }
    function hex(s) {return String(s).replace(/^0x/i,'').replace(/^0+/,'').toUpperCase()||'0';}
    function t1(n) {
        // Interfaces can repeat the same VID/PID/serial; count the host device once.
        if(n.IOObjectClass!=='IOUSBHostDevice')return null;
        if(n.idVendor!==0x05ac || [0x1227,0x1281].indexOf(n.idProduct)<0)return null;
        var s=String(n['USB Serial Number']||''),c=/\bCPID:([0-9a-f]+)/i.exec(s),b=/\bBDID:([0-9a-f]+)/i.exec(s),e=/\bECID:([0-9a-f]+)/i.exec(s);
        // Verified T1 x619ap identity. Never match an iPhone or Watch by PID alone.
        if(!c||parseInt(c[1],16)!==0x8002||!b||parseInt(b[1],16)!==0x12||!e)return null;
        return {ecid:hex(e[1]),board:parseInt(b[1],16),mode:n.idProduct===0x1227?'DFU':'Recovery'};
    }
    var portKeys=['port','UsbConnector','UsbCompanionSS','UsbCompanionSSP','UsbCompanionHS','UsbCompanionFS','UsbCompanionLS','UsbCPortNumber','kUSBSleepPortCurrentLimit','kUSBWakePortCurrentLimit'];
    function inventory(c) {
        var out={},numbers={};
        (c.IORegistryEntryChildren||[]).forEach(function(p){
            if(!/AppleUSB.*Port$/.test(p.IOObjectClass||''))return;
            var n=portNumber(p.port),name=p.IORegistryEntryName;
            if(!/^[A-Za-z0-9_-]{1,24}$/.test(name)||out[name]||numbers[n])fail('Ambiguous USB port inventory');
            numbers[n]=true;out[name]={};portKeys.forEach(function(k){if(p[k]!==undefined)out[name][k]=copy(p[k]);});
            if(typeof p.UsbConnector!=='number')fail('USB connector type missing: '+name);
        });
        if(!Object.keys(out).length||Object.keys(out).length>15)fail('USB port inventory is empty or exceeds 15 ports');return out;
    }
    function signature(c) {return {name:c.IORegistryEntryName,provider:c.IOObjectClass,location:c.locationID};}
    function locate(tree,model,darwin) {
        if(!/^MacBookPro(?:13|14),[123]$/.test(model))fail('Unsupported effective Mac model: '+model+'; requires a separate review');
        var hits=[];walk(tree,function(n,a){var id=t1(n);if(id)hits.push({n:n,a:a,id:id});});
        if(hits.length!==1)fail(hits.length?'Multiple T1 devices; refusing':'T1 DFU/Recovery not visible. It may already be hidden.');
        var h=hits[0],p=h.a[h.a.length-1],c=h.a[h.a.length-2];
        // SHC1/XHC1 aliases are allowed, arbitrary external controllers/hubs are not.
        if(!p||!c||c.IOObjectClass!=='AppleUSBXHCISPTLP'||!/^(SHC|XHC)[0-9]$/.test(c.IORegistryEntryName||''))fail('T1 is not directly on an Intel internal root USB port');
        if(h.n['Built-In']!==true||p.UsbConnector!==255)fail('The T1 root port is not marked internal');
        var others=[];walk(p,function(n){if(n!==h.n&&n.IOObjectClass==='IOUSBHostDevice')others.push(n);});
        if(others.length)fail('Another USB device shares this root port; refusing');
        var ports=inventory(c),name=p.IORegistryEntryName,number=portNumber(p.port);
        if(!ports[name])fail('Target port not in controller inventory');
        return {schema:1,model:model,darwin:String(darwin),ecid:h.id.ecid,board:h.id.board,mode:h.id.mode,
            controller:signature(c),target:{name:name,number:number},ports:ports};
    }
    function personality(plan,profileID) {
        var ports=copy(plan.ports);delete ports[plan.target.name];
        if(!Object.keys(ports).length)fail('Refusing to remove the only USB port');
        var high=Math.max.apply(null,Object.keys(plan.ports).map(function(k){return portNumber(plan.ports[k].port);}));
        return {CFBundleIdentifier:'com.apple.driver.AppleUSBHostMergeProperties',IOClass:'AppleUSBHostMergeProperties',
            IOProviderClass:plan.controller.provider,IONameMatch:plan.controller.name,IOPropertyMatch:{locationID:plan.controller.location},model:plan.model,
            IOProviderMergeProperties:{ports:ports,'port-count':portData(high),T1USBPatchProfile:profileID,T1USBPatchECID:plan.ecid,T1USBPatchTarget:plan.target.name}};
    }
    function samePlan(a,b) {
        return a.model===b.model&&a.darwin===b.darwin&&hex(a.ecid)===hex(b.ecid)&&a.board===b.board&&eq(a.controller,b.controller)&&eq(a.target,b.target)&&eq(a.ports,b.ports);
    }
    function verifyHidden(tree,plan,id) {
        var cs=[],seen=[];walk(tree,function(n){if(t1(n))seen.push(n);if(eq(signature(n),plan.controller))cs.push(n);});
        if(seen.length||cs.length!==1)fail('T1 remains visible or controller is ambiguous');
        var c=cs[0],wanted=copy(plan.ports);delete wanted[plan.target.name];
        if(c.T1USBPatchProfile!==id||c.T1USBPatchECID!==plan.ecid||!eq(inventory(c),wanted))fail('The test profile is not active or the USB inventory differs');
        return true;
    }
    function path(s) {if(typeof s!=='string'||!s||s.charAt(0)==='/'||s.indexOf('\\')>=0||s.split('/').some(function(x){return !x||x==='.'||x==='..';}))fail('Unsafe OpenCore path: '+s);return s;}
    function newMap() {return {CFBundleIdentifier:'org.t1usb.patch.map',CFBundleName:'T1-USB-Map',CFBundleVersion:'1.0.0',CFBundleInfoDictionaryVersion:'6.0',CFBundlePackageType:'KEXT',OSBundleRequired:'Root',IOKitPersonalities_x86_64:{}};}
    function patchMap(mapping,p) {
        var m=copy(mapping),total=0;
        ['IOKitPersonalities','IOKitPersonalities_x86_64'].forEach(function(k){
            if(m[k]!==undefined&&(!m[k]||typeof m[k]!=='object'||Array.isArray(m[k])))fail('Malformed USB map');
            Object.keys(m[k]||{}).forEach(function(name){
                var old=m[k][name],merge=old.IOProviderMergeProperties||{};
                if((merge.T1USBPatchProfile||merge.T1HideTestMap)&&old.IONameMatch===p.IONameMatch&&old.IOProviderClass===p.IOProviderClass&&old.model===p.model) {delete m[k][name];}
                else total++;
            });
        });
        if(total)fail('Existing USB map contains other personalities. Automatic replacement is disabled; save the report for review.');
        m.IOKitPersonalities_x86_64=m.IOKitPersonalities_x86_64||{};
        m.IOKitPersonalities_x86_64['T1-USB-Hide']=copy(p);return m;
    }
    return {parse:parse,xml:xml,copy:copy,eq:eq,stable:stable,walk:walk,t1:t1,locate:locate,inventory:inventory,
        signature:signature,personality:personality,samePlan:samePlan,verifyHidden:verifyHidden,path:path,patchMap:patchMap,newMap:newMap,portNumber:portNumber,hex:hex};
}());
if(typeof module!=='undefined')module.exports=T1Patch;
