#!/bin/bash
# Creates a local app and portable ZIP; never changes boot files or T1 state.
set -eu
package_dir="$(cd -- "$(dirname -- "$0")" && pwd -P)"
output_parent="${1:-$HOME/Desktop}"
/bin/mkdir -p "$output_parent"
/usr/bin/osascript -l JavaScript "$package_dir/patch.js" "$package_dir" --self-check
app_build_dir=$(/usr/bin/mktemp -d "$output_parent/T1-USB-Patch-EN.XXXXXX")
app_path="$app_build_dir/T1 USB Patch EN.app"
/usr/bin/osacompile -l JavaScript -o "$app_path" "$package_dir/patch.js"
/bin/cp "$package_dir/patch.js" "$package_dir/Rollback.command" "$package_dir/README.txt" "$package_dir/LICENSE" "$app_path/Contents/Resources/"
/usr/bin/plutil -replace CFBundleIdentifier -string 'org.t1usb.patch.en' "$app_path/Contents/Info.plist"
/usr/bin/plutil -replace CFBundleShortVersionString -string '1.0.1' "$app_path/Contents/Info.plist"
/usr/bin/codesign --force --sign - "$app_path"
/usr/bin/codesign --verify --deep --strict "$app_path"
/bin/cp -R "$package_dir" "$app_build_dir/T1-USB-Patch-command"
/bin/cp "$package_dir/README.txt" "$app_build_dir/README.txt"
/usr/bin/ditto -c -k --sequesterRsrc --keepParent "$app_build_dir" "$app_build_dir.zip"
/bin/mv "$app_build_dir.zip" "$app_build_dir/T1-USB-Patch-EN-Portable.zip"
printf '\nAPP READY: %s\nPORTABLE ZIP: %s\nNo boot files or T1 state changed.\n' "$app_path" "$app_build_dir/T1-USB-Patch-EN-Portable.zip"
/usr/bin/open "$app_build_dir"
