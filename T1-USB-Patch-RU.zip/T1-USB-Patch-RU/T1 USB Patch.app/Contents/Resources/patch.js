/* T1 USB Patch 1.0: portable, dependency-free planning and typed plist codec. */
var T1Patch = (function () {
    'use strict';
    function fail(s) { throw new Error(s); }
    function copy(x) { return JSON.parse(JSON.stringify(x)); }
    function stable(x) {
        if (Array.isArray(x)) return '[' + x.map(stable).join(',') + ']';
        if (x && typeof x === 'object') return '{' + Object.keys(x).sort().map(function (k) {
            return JSON.stringify(k) + ':' + stable(x[k]);
        }).join(',') + '}';
        return JSON.stringify(x);
    }
    function eq(a,b) { return stable(a) === stable(b); }
    function unesc(s) {
        return s.replace(/&(#x[0-9a-f]+|#[0-9]+|amp|lt|gt|quot|apos);/gi, function (_,e) {
            var names={amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"};
            if (e.charAt(0)!=='#') return names[e];
            var n=e.charAt(1).toLowerCase()==='x'?parseInt(e.slice(2),16):parseInt(e.slice(1),10);
            if (n>65535) {n-=65536;return String.fromCharCode(55296+(n>>10),56320+(n&1023));}
            return String.fromCharCode(n);
        });
    }
    function parse(xml) {
        var tokens=xml.replace(/<\?[\s\S]*?\?>|<!DOCTYPE[^>]*>|<!--[\s\S]*?-->/g,'').match(/<[^>]*>|[^<]+/g)||[], i=0;
        function ws() {while(i<tokens.length && /^\s*$/.test(tokens[i])) i++;}
        function node() {
            ws(); var t=tokens[i++],m=/^<(dict|array|string|key|integer|real|data|date|true|false)(\s*\/?)>$/.exec(t||'');
            if(!m) fail('Unsupported plist element: '+t);
            var kind=m[1],empty=m[2].indexOf('/')>=0,out,txt='';
            if(kind==='dict'||kind==='array') {
                out=kind==='dict'?{}:[];
                if(empty) return out;
                while(true) {
                    ws();if(tokens[i]==='</'+kind+'>') {i++;return out;}
                    if(kind==='dict') {
                        if(!/^<key(?:\s*\/?)>/.test(tokens[i]||'')) fail('Expected plist key');
                        var k=node();if(Object.prototype.hasOwnProperty.call(out,k))fail('Duplicate plist key');
                        out[k]=node();
                    } else out.push(node());
                }
            }
            if(!empty) {
                if(tokens[i] && tokens[i].charAt(0)!=='<')txt=tokens[i++];
                if(tokens[i++]!=='</'+kind+'>')fail('Malformed plist '+kind);
            }
            if(kind==='true'||kind==='false')return kind==='true';
            if(kind==='data')return {$data:txt.replace(/\s/g,'')};
            if(kind==='date')return {$date:txt};
            if(kind==='integer') {
                txt=txt.trim();if(!/^-?(?:[0-9]+|0x[0-9a-f]+)$/i.test(txt))fail('Bad plist integer');
                var n=Number(txt);return Math.abs(n)>9007199254740991?{$integer:txt}:n;
            }
            if(kind==='real') {var r=Number(txt);if(!isFinite(r))fail('Unsupported non-finite real');return {$real:txt};}
            return unesc(txt);
        }
        ws();if(!/^<plist\s+version="1\.0"\s*>$/.test(tokens[i++]||''))fail('Not an XML plist');
        var result=node();ws();if(tokens[i++]!=='</plist>')fail('Incomplete plist');ws();
        if(i!==tokens.length)fail('Trailing plist data');return result;
    }
    function xml(x) {
        function esc(s) {return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
        function item(v) {
            if(v===true||v===false)return v?'<true/>':'<false/>';
            if(typeof v==='string')return '<string>'+esc(v)+'</string>';
            if(typeof v==='number') {
                if(!isFinite(v)||Math.floor(v)!==v||Math.abs(v)>9007199254740991)fail('Unsafe integer');
                return '<integer>'+v+'</integer>';
            }
            if(Array.isArray(v))return '<array>'+v.map(item).join('')+'</array>';
            if(!v||typeof v!=='object')fail('Unsupported plist value');
            if(Object.keys(v).length===1) {
                if(v.$data!==undefined)return '<data>'+esc(v.$data)+'</data>';
                if(v.$date!==undefined)return '<date>'+esc(v.$date)+'</date>';
                if(v.$integer!==undefined)return '<integer>'+esc(v.$integer)+'</integer>';
                if(v.$real!==undefined)return '<real>'+esc(v.$real)+'</real>';
            }
            return '<dict>'+Object.keys(v).map(function(k){return '<key>'+esc(k)+'</key>'+item(v[k]);}).join('')+'</dict>';
        }
        return '<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0">'+item(x)+'</plist>\n';
    }
    var b64='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    function bytes(d) {
        if(!d||typeof d.$data!=='string'||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(d.$data))fail('Invalid plist data');
        var a=[],bits=0,v=0;
        d.$data.replace(/=/g,'').split('').forEach(function(c){v=(v<<6)|b64.indexOf(c);bits+=6;if(bits>=8){bits-=8;a.push((v>>bits)&255);}});return a;
    }
    function portNumber(p) {
        var a=bytes(p);if(a.length!==4)fail('Port is not four-byte data');
        var n=a[0]+a[1]*256+a[2]*65536+a[3]*16777216;if(n<1||n>255)fail('Unexpected physical port number');return n;
    }
    function portData(n) {
        var a=[n&255,(n>>8)&255,(n>>16)&255,(n>>24)&255],s='',v=0,b=0;
        a.forEach(function(x){v=(v<<8)|x;b+=8;while(b>=6){b-=6;s+=b64[(v>>b)&63];}});
        if(b)s+=b64[(v<<(6-b))&63];while(s.length%4)s+='=';return {$data:s};
    }
    function walk(n,f,anc) {
        anc=anc||[];if(Array.isArray(n)){n.forEach(function(x){walk(x,f,anc);});return;}
        if(!n||typeof n!=='object')return;f(n,anc);
        (n.IORegistryEntryChildren||[]).forEach(function(x){walk(x,f,anc.concat([n]));});
    }
    function hex(s) {return String(s).replace(/^0x/i,'').replace(/^0+/,'').toUpperCase()||'0';}
    function t1(n) {
        // Interfaces can repeat the same VID/PID/serial; count the host device once.
        if(n.IOObjectClass!=='IOUSBHostDevice')return null;
        if(n.idVendor!==0x05ac || [0x1227,0x1281].indexOf(n.idProduct)<0)return null;
        var s=String(n['USB Serial Number']||''),c=/\bCPID:([0-9a-f]+)/i.exec(s),b=/\bBDID:([0-9a-f]+)/i.exec(s),e=/\bECID:([0-9a-f]+)/i.exec(s);
        // Verified T1 x619ap identity. Never match an iPhone or Watch by PID alone.
        if(!c||parseInt(c[1],16)!==0x8002||!b||parseInt(b[1],16)!==0x12||!e)return null;
        return {ecid:hex(e[1]),board:parseInt(b[1],16),mode:n.idProduct===0x1227?'DFU':'Recovery'};
    }
    var portKeys=['port','UsbConnector','UsbCompanionSS','UsbCompanionSSP','UsbCompanionHS','UsbCompanionFS','UsbCompanionLS','UsbCPortNumber','kUSBSleepPortCurrentLimit','kUSBWakePortCurrentLimit'];
    function inventory(c) {
        var out={},numbers={};
        (c.IORegistryEntryChildren||[]).forEach(function(p){
            if(!/AppleUSB.*Port$/.test(p.IOObjectClass||''))return;
            var n=portNumber(p.port),name=p.IORegistryEntryName;
            if(!/^[A-Za-z0-9_-]{1,24}$/.test(name)||out[name]||numbers[n])fail('Ambiguous USB port inventory');
            numbers[n]=true;out[name]={};portKeys.forEach(function(k){if(p[k]!==undefined)out[name][k]=copy(p[k]);});
            if(typeof p.UsbConnector!=='number')fail('USB connector type missing: '+name);
        });
        if(!Object.keys(out).length||Object.keys(out).length>15)fail('USB port inventory is empty or exceeds 15 ports');return out;
    }
    function signature(c) {return {name:c.IORegistryEntryName,provider:c.IOObjectClass,location:c.locationID};}
    function locate(tree,model,darwin) {
        if(!/^MacBookPro(?:13|14),[123]$/.test(model))fail('Unsupported effective Mac model: '+model+'; requires a separate review');
        var hits=[];walk(tree,function(n,a){var id=t1(n);if(id)hits.push({n:n,a:a,id:id});});
        if(hits.length!==1)fail(hits.length?'Multiple T1 devices; refusing':'T1 DFU/Recovery not visible. It may already be hidden.');
        var h=hits[0],p=h.a[h.a.length-1],c=h.a[h.a.length-2];
        // SHC1/XHC1 aliases are allowed, arbitrary external controllers/hubs are not.
        if(!p||!c||c.IOObjectClass!=='AppleUSBXHCISPTLP'||!/^(SHC|XHC)[0-9]$/.test(c.IORegistryEntryName||''))fail('T1 is not directly on an Intel internal root USB port');
        if(h.n['Built-In']!==true||p.UsbConnector!==255)fail('The T1 root port is not marked internal');
        var others=[];walk(p,function(n){if(n!==h.n&&n.IOObjectClass==='IOUSBHostDevice')others.push(n);});
        if(others.length)fail('Another USB device shares this root port; refusing');
        var ports=inventory(c),name=p.IORegistryEntryName,number=portNumber(p.port);
        if(!ports[name])fail('Target port not in controller inventory');
        return {schema:1,model:model,darwin:String(darwin),ecid:h.id.ecid,board:h.id.board,mode:h.id.mode,
            controller:signature(c),target:{name:name,number:number},ports:ports};
    }
    function personality(plan,profileID) {
        var ports=copy(plan.ports);delete ports[plan.target.name];
        if(!Object.keys(ports).length)fail('Refusing to remove the only USB port');
        var high=Math.max.apply(null,Object.keys(plan.ports).map(function(k){return portNumber(plan.ports[k].port);}));
        return {CFBundleIdentifier:'com.apple.driver.AppleUSBHostMergeProperties',IOClass:'AppleUSBHostMergeProperties',
            IOProviderClass:plan.controller.provider,IONameMatch:plan.controller.name,IOPropertyMatch:{locationID:plan.controller.location},model:plan.model,
            IOProviderMergeProperties:{ports:ports,'port-count':portData(high),T1USBPatchProfile:profileID,T1USBPatchECID:plan.ecid,T1USBPatchTarget:plan.target.name}};
    }
    function samePlan(a,b) {
        return a.model===b.model&&a.darwin===b.darwin&&hex(a.ecid)===hex(b.ecid)&&a.board===b.board&&eq(a.controller,b.controller)&&eq(a.target,b.target)&&eq(a.ports,b.ports);
    }
    function verifyHidden(tree,plan,id) {
        var cs=[],seen=[];walk(tree,function(n){if(t1(n))seen.push(n);if(eq(signature(n),plan.controller))cs.push(n);});
        if(seen.length||cs.length!==1)fail('T1 remains visible or controller is ambiguous');
        var c=cs[0],wanted=copy(plan.ports);delete wanted[plan.target.name];
        if(c.T1USBPatchProfile!==id||c.T1USBPatchECID!==plan.ecid||!eq(inventory(c),wanted))fail('The test profile is not active or the USB inventory differs');
        return true;
    }
    function path(s) {if(typeof s!=='string'||!s||s.charAt(0)==='/'||s.indexOf('\\')>=0||s.split('/').some(function(x){return !x||x==='.'||x==='..';}))fail('Unsafe OpenCore path: '+s);return s;}
    function newMap() {return {CFBundleIdentifier:'org.t1usb.patch.map',CFBundleName:'T1-USB-Map',CFBundleVersion:'1.0.0',CFBundleInfoDictionaryVersion:'6.0',CFBundlePackageType:'KEXT',OSBundleRequired:'Root',IOKitPersonalities_x86_64:{}};}
    function patchMap(mapping,p) {
        var m=copy(mapping),total=0;
        ['IOKitPersonalities','IOKitPersonalities_x86_64'].forEach(function(k){
            if(m[k]!==undefined&&(!m[k]||typeof m[k]!=='object'||Array.isArray(m[k])))fail('Malformed USB map');
            Object.keys(m[k]||{}).forEach(function(name){
                var old=m[k][name],merge=old.IOProviderMergeProperties||{};
                if((merge.T1USBPatchProfile||merge.T1HideTestMap)&&old.IONameMatch===p.IONameMatch&&old.IOProviderClass===p.IOProviderClass&&old.model===p.model) {delete m[k][name];}
                else total++;
            });
        });
        if(total)fail('Existing USB map contains other personalities. Automatic replacement is disabled; save the report for review.');
        m.IOKitPersonalities_x86_64=m.IOKitPersonalities_x86_64||{};
        m.IOKitPersonalities_x86_64['T1-USB-Hide']=copy(p);return m;
    }
    return {parse:parse,xml:xml,copy:copy,eq:eq,stable:stable,walk:walk,t1:t1,locate:locate,inventory:inventory,
        signature:signature,personality:personality,samePlan:samePlan,verifyHidden:verifyHidden,path:path,patchMap:patchMap,newMap:newMap,portNumber:portNumber,hex:hex};
}());
if(typeof module!=='undefined')module.exports=T1Patch;

/* Native macOS adapter; all device and plist decisions are in engine.js. */
function run(argv) {
    'use strict';
    ObjC.import('Foundation');
    var E=T1Patch,app=Application.currentApplication();app.includeStandardAdditions=true;
    var fm=$.NSFileManager.defaultManager,home=ObjC.unwrap($.NSHomeDirectory()),desk=home+'/Desktop';
    var title='T1 USB Patch 1.0',log='',activeWrite=false;
    var resources=argv.length?String(argv[0]):ObjC.unwrap($.NSBundle.mainBundle.resourcePath);
    var storage=home+'/Library/Application Support/T1 USB Patch';
    function fail(s){throw new Error(s);}
    function exists(p){return !!fm.fileExistsAtPath($(p));}
    function data(p){var d=$.NSData.dataWithContentsOfFile($(p));if(!d)fail('Не удалось прочитать '+p);return d;}
    function writeData(p,d){if(!d.writeToFileAtomically($(p),true))fail('Не удалось записать '+p);}
    function text(p){var s=$.NSString.alloc.initWithDataEncoding(data(p),$.NSUTF8StringEncoding);if(!s)fail('Не UTF-8: '+p);return ObjC.unwrap(s);}
    function write(p,s){if(!$(String(s)).writeToFileAtomicallyEncodingError($(p),true,$.NSUTF8StringEncoding,null))fail('Не удалось записать '+p);}
    function mkdir(p){if(!fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError($(p),true,$({NSFilePosixPermissions:448}),null))fail('Не удалось создать '+p);}
    function copy(a,b){if(exists(b))fail('Файл назначения уже существует: '+b);if(!fm.copyItemAtPathToPathError($(a),$(b),null))fail('Не удалось скопировать '+a+' → '+b);}
    function remove(p){if(!fm.removeItemAtPathError($(p),null))fail('Не удалось удалить '+p);}
    function cap(exe,args){
        var t=$.NSTask.alloc.init,p=$.NSPipe.pipe;
        t.launchPath=$(exe);t.arguments=$(args);t.standardOutput=p;t.standardError=p;
        var env=ObjC.deepUnwrap($.NSProcessInfo.processInfo.environment);
        Object.keys(env).forEach(function(k){if(/^(DYLD_|LD_)/.test(k))delete env[k];});
        t.environment=$(env);t.launch;
        var d=p.fileHandleForReading.readDataToEndOfFile;t.waitUntilExit;
        var s=ObjC.unwrap($.NSString.alloc.initWithDataEncoding(d,$.NSUTF8StringEncoding))||'';
        if(Number(t.terminationStatus)!==0)fail(exe+' завершился с ошибкой: '+s.slice(-1500));return s;
    }
    function hash(p){var h=cap('/usr/bin/shasum',['-a','256',p]).split(/\s+/)[0];if(!/^[0-9a-f]{64}$/.test(h))fail('Ошибка SHA-256');return h;}
    function plist(p){return E.parse(cap('/usr/bin/plutil',['-convert','xml1','-o','-',p]));}
    function json(p){return JSON.parse(text(p));}
    function saveJSON(p,o){write(p,JSON.stringify(o,null,2)+'\n');}
    function savePlist(p,o){write(p,E.xml(o));cap('/usr/bin/plutil',['-lint',p]);if(!E.eq(plist(p),o))fail('Проверка plist после записи не прошла: '+p);}
    function stamp(){return new Date().toISOString().replace(/[:.]/g,'-');}
    function message(s){app.displayDialog(s,{withTitle:title,buttons:['Закрыть'],defaultButton:'Закрыть'});}
    function confirm(s,label){return app.displayDialog(s,{withTitle:title,buttons:['Отмена',label],defaultButton:'Отмена',cancelButton:'Отмена'}).buttonReturned===label;}
    function folder(prompt,initial){
        var opts={withPrompt:prompt};if(initial&&exists(initial))opts.defaultLocation=Path(initial);
        return String(app.chooseFolder(opts)).replace(/\/$/,'');
    }
    function real(p){return ObjC.unwrap($(p).stringByStandardizingPath.stringByResolvingSymlinksInPath);}
    function noLinks(p){var q=p;while(!exists(q)&&q!=='/')q=q.split('/').slice(0,-1).join('/')||'/';if(real(q)!==q)fail('Символическая ссылка в пути: '+p);}
    function safeOC(p){
        if(real(p)!==p||!/(?:^|\/)EFI\/OC$/.test(p)||p.indexOf('/dev/')===0||p.indexOf('/System/')===0)fail('Выберите настоящую папку EFI/OC без символических ссылок');
        if(!exists(p+'/config.plist')||!exists(p+'/OpenCore.efi'))fail('В выбранной папке нет config.plist и OpenCore.efi');
        noLinks(p+'/config.plist');noLinks(p+'/OpenCore.efi');
        return p;
    }
    function ocFolder(){return safeOC(folder('Выбери папку EFI/OC используемого OpenCore. Проверь том: START или EFI.','/Volumes/START/EFI/OC'));}
    function tree(){return E.parse(cap('/usr/sbin/ioreg',['-a','-l','-r','-c','AppleUSBHostController']));}
    function model(){return cap('/usr/sbin/sysctl',['-n','hw.model']).trim();}
    function darwin(){return cap('/usr/sbin/sysctl',['-n','kern.osrelease']).trim().split('.')[0];}
    function locate(){return E.locate(tree(),model(),darwin());}
    function readKnown(){return json(resources+'/known-profile.json');}
    function canWrite(p){if(!fm.isWritableFileAtPath($(p)))fail('Нет доступа на запись: '+p+'\nМонтирование и повышение прав пакет не выполняет.');}
    function linksAndFiles(oc){
        var out={},it=fm.enumeratorAtPath($(oc)),x;
        while((x=it.nextObject)){var rel=ObjC.unwrap(x),p=oc+'/'+rel;
            E.path(rel);var a=fm.attributesOfItemAtPathError($(p),null),type=ObjC.unwrap(a.objectForKey($.NSFileType));
            if(type==='NSFileTypeSymbolicLink')fail('Символическая ссылка в OC: '+rel);
            if(type==='NSFileTypeRegular')out[rel]=hash(p);
            else if(type!=='NSFileTypeDirectory')fail('Необычный файл в OC: '+rel);
        }return out;
    }
    function assertSnapshot(root,snap){Object.keys(snap).forEach(function(r){if(!exists(root+'/'+r)||hash(root+'/'+r)!==snap[r])fail('Исходный OpenCore изменился: '+r);});}
    function context(oc,plan,id){
        var cfg=plist(oc+'/config.plist'),entries=cfg.Kernel&&cfg.Kernel.Add;
        if(!Array.isArray(entries))fail('В config.plist нет Kernel/Add');
        var maps=[];
        entries.forEach(function(e){
            if(e.Enabled!==true)return;E.path(e.BundlePath);
            if(/USBToolBox|UTBMap|USBInjectAll|GenericUSBXHCI/i.test(e.BundlePath))fail('Включён другой механизм USB: '+e.BundlePath+'; нужна отдельная проверка');
            var pp=e.PlistPath||'Contents/Info.plist';E.path(pp);
            var f=oc+'/Kexts/'+e.BundlePath+'/'+pp;if(!exists(f))fail('Отсутствует включённый kext: '+f);noLinks(f);
            var m=plist(f),isMap=/USB.?Map|USBPorts|T1-USB-Map/i.test(e.BundlePath),hasPorts=false;
            ['IOKitPersonalities','IOKitPersonalities_x86_64'].forEach(function(k){Object.keys(m[k]||{}).forEach(function(n){
                var p=m[k][n],v=p.IOProviderMergeProperties||{};if(v.ports||v.portCount||v['port-count'])hasPorts=true;
            });});
            if(isMap||hasPorts){if(e.ExecutablePath||pp!=='Contents/Info.plist'||e.BundlePath.indexOf('/')>=0)fail('Нестандартная USB-карта требует отдельной проверки');maps.push({entry:e,relative:'Kexts/'+e.BundlePath+'/'+pp,map:m});}
        });
        if(maps.length>1)fail('Включено несколько USB-карт; автоматическая замена запрещена');
        var p=E.personality(plan,id),result={config:cfg,changeConfig:false,files:[]},map;
        if(maps.length){map=maps[0];map.map=E.patchMap(map.map,p);}
        else {
            var rel='Kexts/T1-USB-Map.kext/Contents/Info.plist';if(exists(oc+'/Kexts/T1-USB-Map.kext'))fail('Найдена отключённая T1-USB-Map.kext. Нужна ручная проверка');
            map={relative:rel,map:E.patchMap(E.newMap(),p)};
            cfg.Kernel.Add.push({Arch:'x86_64',BundlePath:'T1-USB-Map.kext',Comment:'T1 internal USB port exclusion',Enabled:true,ExecutablePath:'',MaxKernel:'',MinKernel:'',PlistPath:'Contents/Info.plist'});
            result.changeConfig=true;
        }
        result.map=map;return result;
    }
    function selfCheck(){
        var f=storage+'/self-check.plist',sample={text:'Тест & < > "',bytes:{$data:'AwAAAA=='},large:{$integer:'18446744073709551615'},real:{$real:'1.25'},yes:true,no:false,array:[1,-1,'x'],empty:{}};
        savePlist(f,sample);remove(f);
        if(cap('/usr/bin/uname',['-m']).trim()!=='x86_64')fail('Пакет предназначен для Intel MacBook Pro с T1');
    }
    function diagnose(){
        var t=tree(),hits=[],markers=[];
        E.walk(t,function(n){var id=E.t1(n);if(id)hits.push(id);if(n.T1USBPatchProfile||n.T1HideTestMap)markers.push({controller:E.signature(n),profile:n.T1USBPatchProfile||n.T1HideTestMap,ports:E.inventory(n)});});
        var report={version:'1.0',model:model(),darwin:darwin(),T1:hits,markers:markers};
        try{report.plan=E.locate(t,report.model,report.darwin);}catch(e){report.note=String(e);}
        var out=desk+'/T1-USB-Report-'+stamp()+'.json';saveJSON(out,report);
        message((hits.length?'T1: '+hits.map(function(h){return h.mode+' / ECID '+h.ecid;}).join(', '):'T1 в DFU/Recovery не виден.')+'\n'+(markers.length?'Метка карты USB активна.':'Активная метка нашего патча не найдена.')+'\n\nОтчёт: '+out);
    }
    function prepare(){
        var plan=locate(),oc=ocFolder(),id='T1USB-'+stamp(),c=context(oc,plan,id),snap=linksAndFiles(oc);
        var volume=oc.slice(0,-'/EFI/OC'.length),boots=[volume+'/EFI/BOOT/BOOTx64.efi',volume+'/System/Library/CoreServices/boot.efi'];
        var boot=boots.filter(exists)[0];if(!boot)fail('На томе OpenCore не найден исходный BOOTx64.efi/boot.efi. Нужна отдельная проверка загрузки');
        if(real(boot)!==boot)fail('Загрузочный файл является ссылкой');
        var bootHash=hash(boot),out=desk+'/T1-USB-Test-'+stamp();mkdir(out);
        write(out+'/INCOMPLETE.txt','Не использовать до появления READY.txt.');
        mkdir(out+'/EFI');copy(oc,out+'/EFI/OC');mkdir(out+'/EFI/BOOT');copy(boot,out+'/EFI/BOOT/BOOTx64.efi');
        var test=E.copy(c.config);if(!test.Misc||!test.Misc.Boot)fail('В config нет Misc/Boot');test.Misc.Boot.LauncherOption='Disabled';
        savePlist(out+'/EFI/OC/config.plist',test);mkdir(out+'/EFI/OC/'+c.map.relative.split('/').slice(0,-1).join('/'));savePlist(out+'/EFI/OC/'+c.map.relative,c.map.map);
        var copied=linksAndFiles(out+'/EFI/OC'),allowed=['config.plist',c.map.relative];
        Object.keys(snap).forEach(function(r){if(allowed.indexOf(r)<0&&copied[r]!==snap[r])fail('Изменилась копия другого файла: '+r);});
        Object.keys(copied).forEach(function(r){if(!snap[r]&&allowed.indexOf(r)<0)fail('Лишний файл в копии: '+r);});
        assertSnapshot(oc,snap);if(hash(boot)!==bootHash)fail('Исходный bootstrap изменился');
        var ticket={schema:1,id:id,plan:plan,source:oc,snapshot:snap,mapRelative:c.map.relative,created:new Date().toISOString()};
        saveJSON(out+'/profile.json',ticket);mkdir(out+'/Original-files');copy(oc+'/config.plist',out+'/Original-files/config.plist');
        if(exists(oc+'/'+c.map.relative))copy(oc+'/'+c.map.relative,out+'/Original-files/USB-Map-Info.plist');
        write(out+'/README-RU.txt','ПОДГОТОВЛЕНО ТОЛЬКО НА РАБОЧЕМ СТОЛЕ.\n\n1. Скопируй папку EFI из этого каталога на уже подготовленную FAT32-флешку вручную. Не копируй её на внутренний диск. Если на флешке уже есть EFI, сохрани её отдельно.\n2. Перезагрузи Mac с удержанием Option и выбери EFI Boot флешки, затем macOS. NVRAM не сбрасывай.\n3. Проверь встроенные клавиатуру/тачпад, каждый разъём USB с USB2 и USB3 устройствами и программы прошивки. T1 должен исчезнуть.\n4. Запусти T1 USB Patch, выбери «Установить после USB-теста» и укажи ЭТУ папку (с profile.json).\n5. При проблеме выключи Mac, вынь флешку и загрузи прежний OpenCore. Внутренний загрузчик на этапе подготовки не менялся.\n\nПорт '+plan.target.name+' / номер '+plan.target.number+'; ECID '+plan.ecid+'.\n');
        remove(out+'/INCOMPLETE.txt');write(out+'/READY.txt','Готово для ручного копирования EFI на тестовую флешку.\n');
        cap('/usr/bin/open',[out]);message('Тестовые файлы готовы на Рабочем столе:\n'+out+'\n\nT1: '+plan.target.name+' / ECID '+plan.ecid+'\nИсходный OpenCore не изменён. На флешку ничего не записано. Прочитай README-RU.txt.');
    }
    function transaction(oc,c,profile){
        safeOC(oc);canWrite(oc);canWrite(oc+'/config.plist');
        var changes=[{relative:c.map.relative,content:E.xml(c.map.map)}];
        if(c.changeConfig)changes.push({relative:'config.plist',content:E.xml(c.config)});
        var seen={},backup=desk+'/T1-USB-Backup-'+stamp();mkdir(backup);
        var manifest={schema:1,target:oc,created:new Date().toISOString(),changes:[],profile:profile};
        changes.forEach(function(ch,i){
            E.path(ch.relative);if(seen[ch.relative])fail('Duplicate target');seen[ch.relative]=true;
            var p=oc+'/'+ch.relative;noLinks(p);var before=exists(p)?hash(p):null;
            if(before)copy(p,backup+'/original-'+i+'.plist');
            savePlist(backup+'/installed-'+i+'.plist',E.parse(ch.content));
            manifest.changes.push({relative:ch.relative,before:before,after:hash(backup+'/installed-'+i+'.plist'),index:i});
        });
        saveJSON(backup+'/manifest.json',manifest);saveJSON(backup+'/profile.json',profile);
        // Portable rollback can be run even from another macOS installation.
        copy(resources+'/patch.js',backup+'/patch.js');copy(resources+'/Rollback.command',backup+'/Rollback.command');
        write(backup+'/README-RU.txt','Для отката открой Rollback.command. Если macOS не загружается, загрузись с проверенной флешки и открой этот файл.\nОтмена не требует NVRAM reset или удаления разделов.\n');
        if(!confirm('Будет изменено:\n'+manifest.changes.map(function(ch){return oc+'/'+ch.relative;}).join('\n')+'\n\nT1-порт: '+profile.plan.target.name+'\nРезервная копия: '+backup+'\n\nЭто изменение USB-карты загрузчика. Ошибка карты может отключить устройства в macOS; оставь рабочую флешку для отката.\nРазделы и файлы OpenCore.efi/boot.efi не изменяются.','Установить'))return;
        // Check every target before starting, never mount or request admin privileges.
        manifest.changes.forEach(function(ch){var p=oc+'/'+ch.relative;noLinks(p);if((exists(p)?hash(p):null)!==ch.before)fail('Файл изменён перед записью: '+p);if(exists(p))canWrite(p);});
        activeWrite=true;
        try {
            manifest.changes.forEach(function(ch){var p=oc+'/'+ch.relative;mkdir(p.split('/').slice(0,-1).join('/'));write(p,text(backup+'/installed-'+ch.index+'.plist'));if(hash(p)!==ch.after)fail('Не совпал записанный файл '+p);});
        } catch(e) {
            var errors=[];manifest.changes.slice().reverse().forEach(function(ch){try{var p=oc+'/'+ch.relative;if(ch.before){writeData(p,data(backup+'/original-'+ch.index+'.plist'));if(hash(p)!==ch.before)fail('Не совпал восстановленный файл '+p);}else if(exists(p))remove(p);}catch(r){errors.push(String(r));}});
            activeWrite=false;throw new Error(String(e)+'\nПопытка отката: '+(errors.length?errors.join('\n'):'исходные файлы восстановлены')+'\nBackup: '+backup);
        }
        activeWrite=false;
        // Backups must be byte-exact even for binary plist files. Originals were copied, not reserialized.
        saveJSON(backup+'/installed.json',{completed:true,at:new Date().toISOString()});
        mkdir(storage+'/Profiles');profile.tested=true;saveJSON(storage+'/Profiles/'+profile.plan.ecid+'.json',profile);
        message('Патч установлен.\nРезервная копия: '+backup+'\n\nПерезагрузи Mac без тестовой флешки, затем выбери «Проверить и сохранить отчёт». После обновления OCLP карта может потребовать повторной установки.');
    }
    function installTest(){
        var dir=folder('Выбери папку T1-USB-Test с profile.json',desk),ticket=json(dir+'/profile.json');
        if(ticket.schema!==1||!ticket.id||!ticket.plan||!ticket.snapshot)fail('Неверный профиль теста');
        if(model()!==ticket.plan.model||darwin()!==ticket.plan.darwin)fail('Модель или версия macOS изменилась после подготовки теста');
        E.verifyHidden(tree(),ticket.plan,ticket.id);
        if(!confirm('Активна тестовая карта '+ticket.plan.target.name+'.\nТы проверил встроенные клавиатуру/тачпад, все разъёмы USB и нужные программы?\n\nЕсли есть сбои, отмени установку и загрузи прежний OpenCore без флешки.','Всё проверено'))return;
        var oc=safeOC(ticket.source);assertSnapshot(oc,ticket.snapshot);
        var c=context(oc,ticket.plan,ticket.id);if(c.map.relative!==ticket.mapRelative)fail('Изменилось размещение карты');
        transaction(oc,c,{schema:1,id:ticket.id,plan:ticket.plan,tested:true});
    }
    function repeat(){
        var plan;
        try{plan=locate();}catch(e){
            var marked=[];E.walk(tree(),function(n){if(n.T1USBPatchProfile||n.T1HideTestMap)marked.push(n);});
            if(marked.length){message('Карта скрытия T1 уже активна. Повторная установка сейчас не требуется.\nИспользуй «Проверить и сохранить отчёт».');return;}throw e;
        }
        var known=readKnown(),profile=null,saved=storage+'/Profiles/'+plan.ecid+'.json';
        if(exists(saved)){var s=json(saved);if(s.tested&&E.samePlan(s.plan,plan))profile=s;}
        if(!profile&&E.samePlan(known.plan,plan))profile=known;
        if(!profile){
            message('Автоматически сохранённый профиль не найден. Если этот Mac уже проверен, выбери profile.json из его папки T1-USB-Backup. Иначе нажми «Отмена» и выбери «Подготовить USB-тест».');
            var file=String(app.chooseFile({withPrompt:'Выбери сохранённый profile.json проверенного Mac или отмени для USB-теста'})),imported=json(file);
            if(imported.schema!==1||imported.tested!==true||!E.samePlan(imported.plan,plan))fail('Профиль не соответствует текущему Mac, порту или версии macOS');profile=imported;
        }
        var oc=ocFolder(),id='T1USB-'+stamp(),c=context(oc,plan,id);
        if(c.changeConfig)fail('После переустановки изменилась схема включения карты. Сначала нужен USB-тест.');
        transaction(oc,c,{schema:1,id:id,plan:plan,tested:true});
    }
    function restore(dir){
        dir=dir||folder('Выбери папку T1-USB-Backup с manifest.json',desk);
        var m=json(dir+'/manifest.json');if(m.schema!==1||!Array.isArray(m.changes)||!m.changes.length||m.changes.length>2)fail('Неверный manifest');
        var oc=safeOC(m.target),changes=m.changes;
        changes.forEach(function(ch){E.path(ch.relative);if(ch.relative!=='config.plist'&&!/^Kexts\/[^/]+\.kext\/Contents\/Info\.plist$/.test(ch.relative))fail('Неожиданный путь в backup');
            if(!/^[0-9a-f]{64}$/.test(ch.after)||[0,1].indexOf(ch.index)<0)fail('Неверная запись backup');
            if(ch.before&&hash(dir+'/original-'+ch.index+'.plist')!==ch.before)fail('Повреждена резервная копия');
            var p=oc+'/'+ch.relative;noLinks(p);var current=exists(p)?hash(p):null;
            if(current!==ch.after&&current!==ch.before)fail('После установки файл изменён другой программой; откат остановлен: '+p);
            if(exists(p))canWrite(p);canWrite(p.split('/').slice(0,-1).join('/'));
        });
        if(!confirm('Восстановить исходные файлы из:\n'+dir+'\n\nНазначение: '+oc+'\nПатч скрытия T1 будет отменён.','Восстановить'))return;
        changes.slice().reverse().forEach(function(ch){var p=oc+'/'+ch.relative;if((exists(p)?hash(p):null)===ch.before)return;
            if(ch.before){var d=data(dir+'/original-'+ch.index+'.plist');if(!d.writeToFileAtomically($(p),true))fail('Не удалось восстановить '+p);if(hash(p)!==ch.before)fail('Ошибка проверки отката');}
            else remove(p);
        });
        message('Исходные файлы восстановлены. Перезагрузи Mac.\nПустая отключённая папка нового kext, если она была создана, может остаться.');
    }
    try {
        mkdir(storage);selfCheck();
        if(argv.length>1&&argv[1]==='--self-check')return 'T1 USB Patch: native plist and runtime self-check passed. No boot files changed.';
        if(argv.length>1&&argv[1]==='--restore'){restore(argv[2]);return;}
        var choices=['Проверить и сохранить отчёт','Повторить проверенный патч','Подготовить USB-тест','Установить после USB-теста','Откатить из копии'];
        var selection=app.chooseFromList(choices,{withTitle:title,withPrompt:'Скрытие внутреннего T1 в DFU/Recovery для macOS.\nНа другом Mac начни с USB-теста. Это не восстановление прошивки.',defaultItems:[choices[0]],okButtonName:'Продолжить',cancelButtonName:'Закрыть'});
        if(!selection)return;
        var action=String(selection[0]);
        if(action===choices[0])diagnose();if(action===choices[1])repeat();if(action===choices[2])prepare();if(action===choices[3])installTest();if(action===choices[4])restore();
    } catch(e) {
        if(e.errorNumber===-128||String(e).indexOf('User canceled')>=0)return;
        var error=String(e)+(activeWrite?'\nВнимание: ошибка во время записи; используй резервную копию.':'');
        try{log=storage+'/error-'+stamp()+'.txt';write(log,error+'\n');}catch(ignore){}
        message('Операция остановлена.\n\n'+error+'\n\nЖурнал: '+log);
        throw e;
    }
}
