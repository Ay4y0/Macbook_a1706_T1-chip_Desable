T1 Recovery Lite: temporary signed iBSS/iBEC RAM boot; no full restore.
Intel macOS 15. Requires Internet for Apple signing. No app/Homebrew/Python/build dependencies at runtime.
Original manifest is unchanged. Only iBSS/iBEC are packaged. USB hiding must be undone before T1 can be reached.
Source base: https://github.com/niconistal/idevicerestore-t1 at e0cfd9657f04bd57cb15fca66884cef0c5776c22
Original library licenses and modified source/patch are included.
