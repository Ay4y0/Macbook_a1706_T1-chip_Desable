function normalHex(value) {
    return String(value).replace(/^0x/i, '').replace(/^0+/, '').toLowerCase() || '0';
}

function targetMode(tree, ecid) {
    var modes = {};
    function walk(node) {
        if (Array.isArray(node)) { node.forEach(walk); return; }
        if (!node || typeof node !== 'object') return;
        if (Number(node.idVendor) === 0x05ac) {
            var serial = String(node['USB Serial Number'] || '');
            var chip = /\bCPID:([0-9a-f]+)/i.exec(serial);
            var board = /\bBDID:([0-9a-f]+)/i.exec(serial);
            var id = /\bECID:([0-9a-f]+)/i.exec(serial);
            if (chip && board && id && parseInt(chip[1], 16) === 0x8002 &&
                parseInt(board[1], 16) === 0x12 && normalHex(id[1]) === normalHex(ecid)) {
                modes[Number(node.idProduct)] = true;
            }
        }
        Object.keys(node).forEach(function (key) { walk(node[key]); });
    }
    walk(tree);
    var found = Object.keys(modes);
    if (found.length !== 1) return found.length ? 'ambiguous' : 'absent';
    return Number(found[0]) === 0x1281 ? 'recovery' :
           Number(found[0]) === 0x1227 ? 'dfu' : 'other';
}

function outcome(mode) {
    return mode === 'recovery' ? 'success' : 'failure';
}

function run(argv) {
    ObjC.import('Foundation');
    var app = Application.currentApplication();
    app.includeStandardAdditions = true;
    var fm = $.NSFileManager.defaultManager;
    var task = null;
    var logPath = '';
    var selfCheck = argv.length > 0 && argv[0] === '--self-check';
    var root = selfCheck ? String(argv[1]) : ObjC.unwrap($.NSBundle.mainBundle.bundlePath);
    var resource = root + '/Contents/Resources';
    var runtime = root + '/Contents/MacOS';
    var config = JSON.parse(readText(resource + '/config.json'));
    var env = ObjC.deepUnwrap($.NSProcessInfo.processInfo.environment);
    Object.keys(env).forEach(function (key) {
        if (/^(IDEVICERESTORE_|DYLD_|LD_|LIBIRECOVERY_|PERL5LIB$|PERLLIB$|PERL5OPT$)/.test(key)) delete env[key];
    });
    env.IDEVICERESTORE_T1_EMBEDDEDOS = '1';
    var work = ObjC.unwrap($.NSHomeDirectory()) + '/Library/Application Support/T1 Recovery Lite';
    var versionExpected = 't1-recovery-lite 0.1.1 (base 1.0.0-273-g540c352, ' +
        'libirecovery 1.3.1-11-g95dec3a, libtatsu 1.0.5-3-g60a39f3)';

    function readText(path) {
        var text = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, null);
        if (!text) throw new Error('Не удалось прочитать: ' + path);
        return ObjC.unwrap(text);
    }
    function capture(executable, args, directory) {
        task = $.NSTask.alloc.init;
        task.launchPath = $(executable);
        task.arguments = $(args);
        task.environment = $(env);
        if (directory) task.currentDirectoryPath = $(directory);
        var pipe = $.NSPipe.pipe;
        task.standardOutput = pipe;
        task.standardError = pipe;
        task.launch;
        var data = pipe.fileHandleForReading.readDataToEndOfFile;
        task.waitUntilExit;
        var status = Number(task.terminationStatus);
        task = null;
        return {status: status, data: data,
                text: ObjC.unwrap($.NSString.alloc.initWithDataEncoding(data, $.NSUTF8StringEncoding)) || ''};
    }
    function mode() {
        var result = capture('/usr/sbin/ioreg', ['-a', '-p', 'IOUSB', '-l']);
        if (result.status !== 0) throw new Error('Не удалось прочитать USB-состояние.');
        var plist = $.NSPropertyListSerialization.propertyListWithDataOptionsFormatError(result.data, 0, null, null);
        return targetMode(ObjC.deepUnwrap(plist), config.ecid);
    }
    function mkdir(path) {
        var ok = fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError(
            $(path), true, $({NSFilePosixPermissions: 448}), null);
        if (!ok) throw new Error('Не удалось создать папку: ' + path);
    }
    function verify() {
        Object.keys(config.hashes).forEach(function (name) {
            var result = capture('/usr/bin/shasum', ['-a', '256', resource + '/Firmware/' + name]);
            if (result.status !== 0 || result.text.split(/\s+/)[0] !== config.hashes[name])
                throw new Error('Не совпала контрольная сумма: ' + name);
        });
        var result = capture(runtime + '/t1-recovery-core', ['--version']);
        if (result.status !== 0 || result.text.trim() !== versionExpected)
            throw new Error('Не удалось проверить встроенную программу.\n' + result.text.slice(-1200));
    }
    function message(text) {
        app.displayDialog(text, {withTitle: 'T1 Recovery Lite', buttons: ['Закрыть'], defaultButton: 'Закрыть'});
    }

    try {
        if (selfCheck) {
            verify();
            return JSON.stringify({selfCheck: 'passed', mode: mode(), ecid: config.ecid});
        }
        var before = mode();
        if (before === 'recovery') {
            message('T1 уже в Recovery (1281). Повторная передача не нужна.');
            return;
        }
        if (before !== 'dfu') {
            message('Нужный T1 в DFU не обнаружен. Ничего не изменено.\n\nЕсли T1 скрыт картой USB/OpenCore, для перехода потребуется сначала отменить карту и перезагрузить macOS. Приложение карту автоматически не меняет.\n\nЦелевой ECID: ' + config.ecid + '.');
            return;
        }
        app.displayDialog('T1 в DFU (1227). Выполнить одну попытку перехода в Recovery?\n\n' +
            'Нужен интернет для подписи Apple. После перезапуска Mac перевод может понадобиться снова.',
            {withTitle: 'T1 Recovery Lite', buttons: ['Закрыть', 'Перевести в Recovery'],
             defaultButton: 'Перевести в Recovery', cancelButton: 'Закрыть'});
        Progress.totalUnitCount = 4;
        Progress.completedUnitCount = 0;
        Progress.description = 'T1 → Recovery';
        Progress.additionalDescription = 'Проверка встроенных файлов…';
        verify();
        mkdir(work);
        mkdir(work + '/Logs');
        mkdir(work + '/Cache');
        var stamp = new Date().toISOString().replace(/[:.]/g, '-');
        logPath = work + '/Logs/attempt-' + stamp + '.log';
        Progress.completedUnitCount = 1;
        Progress.additionalDescription = 'Подпись Apple и передача загрузчиков. Не переводите Mac в сон.';
        var result = capture(runtime + '/t1-recovery-core', [
            '-d', '-i', '0x' + normalHex(config.ecid), '-C', work + '/Cache',
            '--variant', 'Customer Boot', '--logfile', logPath, resource + '/Firmware'
        ], work);
        Progress.completedUnitCount = 3;
        Progress.additionalDescription = 'Проверка итогового USB-режима…';
        var after = 'absent';
        var consecutive = 0;
        for (var i = 0; i < 20; i++) {
            after = mode();
            consecutive = after === 'recovery' ? consecutive + 1 : 0;
            if (consecutive >= 2) break;
            app.delay(1);
        }
        Progress.totalUnitCount = 0;
        Progress.completedUnitCount = 0;
        Progress.description = '';
        Progress.additionalDescription = '';
        if (consecutive >= 2 && outcome(after) === 'success') {
            message('Готово: T1 в Recovery (1281).\n\nТеперь проверьте программу для iPhone.\n' +
                'После перезапуска Mac перевод может понадобиться снова.\n\nЖурнал: ' + logPath);
        } else {
            message('Recovery не подтверждён. Повторная передача автоматически не выполнялась.\n\n' +
                'Текущий режим: ' + after + '. Код программы: ' + result.status + '.\n\nЖурнал: ' + logPath);
        }
    } catch (error) {
        if (task && task.running) task.terminate;
        if (selfCheck) throw error;
        Progress.totalUnitCount = 0;
        if (error.errorNumber === -128) return;
        message('Операция остановлена: ' + String(error) + (logPath ? '\n\nЖурнал: ' + logPath : ''));
    }
}

if (typeof module !== 'undefined') module.exports = {normalHex: normalHex, targetMode: targetMode, outcome: outcome};
